import BookingForm from '@/components/booking/BookingForm';

const Index = () => {
  return <BookingForm />;
};

export default Index;
